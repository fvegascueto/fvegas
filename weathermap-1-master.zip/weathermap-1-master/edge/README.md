# Edge Service

-  expose **Forecast Service** and **Weather Service** interface
- add auth header（{"auth": "weather"}）


## Access Edge Service

http://localhost:13080/api/forecast/forecast/show

http://localhost:13080/api/weather/weather/show

Note：/api/{microservice-name}/{rest-path}
