package com.service.fusionweather.controller;

import org.junit.Test;

public class TestFusionweatherdata
{

    FusionweatherImpl fusionweatherdataImpl = new FusionweatherImpl();

    @Test
    public void testhelloworld()
    {

    }

}